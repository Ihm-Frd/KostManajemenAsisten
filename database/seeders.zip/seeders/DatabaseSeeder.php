<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Database\Seeders\RoleSeeder;
use Database\Seeders\UserSeeder;
use Database\Seeders\DataKamarSeeder;
use Database\Seeders\DataPenghuniSeeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            DataKamarSeeder::class,
            RoleSeeder::class,
            DataPenghuniSeeder::class,
        ]);
    }
}
